ITIS3155 - taken during the Spring 2019 as a Team Project between 3 other members.

Focuses on the programming lanauge of Ruby.

The program was designed similarily to Cookie Clicker, where the user is able to progress
by interacting with many functions in the website. 

