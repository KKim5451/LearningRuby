class ClickerController < ApplicationController
  def index
  end
end
