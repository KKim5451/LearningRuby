	    var $ = function(id){
	        return document.getElementById(id);
        };
        //your currency
        var money = 0;
        //amount of base currency per player click
        var moneyOnClick = 1;
        //amount of currency per second from upgrades
        var totalCPS = 0;
        window.onload = function(){
	        $("clicker").onclick = manualClick;
	        //The first value is the price of the upgrade, the second is the amount of points it adds per second
	        $("moneyUp").addEventListener("click", function() {upgradeMoney(5,1);}, false);
	        $("upgrade1").addEventListener("click", function() {upgradeCalc(10,1);}, false);
	        $("upgrade2").addEventListener("click", function() {upgradeCalc(20,10);}, false);
	        $("upgrade3").addEventListener("click", function() {upgradeCalc(50,20);}, false);
	        $("upgrade4").addEventListener("click", function() {upgradeCalc(100,100);}, false);
        };
		//adds clicks per second to the total and subtracts price of upgrade
        function upgradeCalc(price, upgrade){
        	if(money >= price){
        		totalCPS += upgrade;
        		money -= price;
        	}
        	updateText();
        }
        function upgradeMoney(price, upgrade){
        	if(money >= price){
        		moneyOnClick += upgrade;
        		money -= price;
        	}
        	updateText();
        }
        //when the user clicks the button add one to money and update the text
        var manualClick = function(){
        	money += moneyOnClick;
	        updateText();
        };
        //updates money every second with the total clicks per second of all upgrades
        var updateMoney = function(){
	        money += totalCPS;
	        updateText();
        };
        //changes the text to show money and clicks per second from upgrades
        var updateText = function(){
        	$("score").innerHTML = money + "\nCPS: " + totalCPS;
        };
        //calls the function 'updateMoney' once every 1000 milliseconds
        var t=setInterval(updateMoney,1000);
        
