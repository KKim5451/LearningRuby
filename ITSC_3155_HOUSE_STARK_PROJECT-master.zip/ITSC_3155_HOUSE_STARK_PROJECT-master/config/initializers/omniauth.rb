OmniAuth.config.logger = Rails.logger
Rails.application.config.middleware.use OmniAuth::Builder do
  provider :google_oauth2, '289117502215-a4htp6i2bjmiq0cn2e2ua0j25u2lov1s.apps.googleusercontent.com', '-9b3Gg8_xmesgO_RPB4byfQA', {client_options: {ssl: {ca_file: Rails.root.join("cacert.pem").to_s}}}
end